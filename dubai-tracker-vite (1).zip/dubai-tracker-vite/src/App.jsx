import { useState } from "react";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, Cell, PieChart, Pie } from "recharts";

const GOLD="#C9A84C",GOLD_DIM="#8B6914",RED="#FF4444",GREEN="#00D4AA",BLUE="#4A9EFF",DARK="#0A0C10",CARD="#0F1318",BORDER="#1E2530";

const destinations=[
  {name:"Switzerland",code:"CH",flag:"🇨🇭",flow:4.2,change:+12.4,reason:"Safe haven banking, neutrality hedge",risk:"LOW",sectors:["Private Banking","Gold Vaults","Real Estate"],color:"#E74C3C"},
  {name:"Singapore",code:"SG",flag:"🇸🇬",flow:3.8,change:+28.7,reason:"Asian pivot, family offices boom",risk:"LOW",sectors:["Family Offices","Equities","Fintech"],color:"#E67E22"},
  {name:"US Treasuries",code:"US",flag:"🇺🇸",flow:6.1,change:+8.2,reason:"Dollar dominance, geopolitical buffer",risk:"LOW-MED",sectors:["T-Bills","Bonds","Equity ETFs"],color:BLUE},
  {name:"Gold & Commodities",code:"XAU",flag:"🥇",flow:5.3,change:+41.2,reason:"War premium, fiat distrust surge",risk:"LOW",sectors:["Physical Gold","Silver","Oil Futures"],color:GOLD},
  {name:"Crypto / BTC",code:"BTC",flag:"₿",flow:2.1,change:+63.8,reason:"Sanctions bypass, borderless store of value",risk:"HIGH",sectors:["Bitcoin","Stablecoins","DeFi"],color:"#F7931A"},
  {name:"London",code:"UK",flag:"🇬🇧",flow:1.4,change:-6.1,reason:"Post-Brexit complexity, slower flows",risk:"MED",sectors:["Real Estate","Hedge Funds","Art"],color:"#9B59B6"},
  {name:"India",code:"IN",flag:"🇮🇳",flow:1.9,change:+19.4,reason:"Diaspora repatriation, strategic neutrality",risk:"MED",sectors:["Equities","Infrastructure","Remittance"],color:"#1ABC9C"},
  {name:"Hong Kong",code:"HK",flag:"🇭🇰",flow:0.8,change:-14.2,reason:"China risk overhang reducing appeal",risk:"MED-HIGH",sectors:["Equities","Real Estate"],color:"#E91E63"},
];

const monthlyFlow=[
  {month:"Sep'24",gold:2.1,crypto:0.9,bonds:3.1,re:2.1},
  {month:"Oct'24",gold:2.4,crypto:1.1,bonds:3.6,re:2.3},
  {month:"Nov'24",gold:3.1,crypto:1.4,bonds:4.2,re:2.5},
  {month:"Dec'24",gold:3.8,crypto:2.1,bonds:5.1,re:2.8},
  {month:"Jan'25",gold:4.4,crypto:2.8,bonds:5.4,re:2.5},
  {month:"Feb'25",gold:5.2,crypto:3.1,bonds:6.1,re:2.9},
  {month:"Mar'25",gold:6.8,crypto:3.9,bonds:7.2,re:3.5},
];

const warRisk=[
  {subject:"Iran Escalation",A:82},{subject:"Red Sea Disruption",A:74},{subject:"Lebanon Spillover",A:61},
  {subject:"Russia Sanctions",A:55},{subject:"Strait of Hormuz",A:68},{subject:"Oil Shock Risk",A:79},
];

const triggers=[
  {date:"Mar 11",event:"US-Iran naval confrontation",impact:"+$2.1B outflow spike",severity:"CRITICAL"},
  {date:"Feb 28",event:"Houthi expansion — Red Sea lanes",impact:"+$1.4B commodities pivot",severity:"HIGH"},
  {date:"Feb 14",event:"Israel-Gaza ceasefire collapse risk",impact:"+$0.9B gold demand",severity:"HIGH"},
  {date:"Jan 30",event:"SWIFT secondary sanction warnings",impact:"Crypto +63% volume",severity:"MED"},
  {date:"Jan 12",event:"UAE diplomatic repositioning signals",impact:"SG family office surge",severity:"MED"},
];

const sectorPie=[
  {name:"US Bonds/T-Bills",value:29.2},{name:"Gold & Commodities",value:25.4},{name:"Private Banking",value:20.1},
  {name:"Crypto/Digital",value:10.0},{name:"Real Estate",value:9.1},{name:"Equities",value:6.2},
];
const PIE_COLORS=[BLUE,GOLD,"#9B59B6","#F7931A",GREEN,"#E74C3C"];

function Ticker() {
  const items=["⚠️ IRAN STRAIT TENSIONS ELEVATED — Gold +2.4%","📊 Dubai DFM Outflows: $21.4B MTD","🔴 Red Sea shipping disruption — 3rd consecutive week","💰 Singapore family offices +28.7% YOY inflows from GCC","⚡ BTC volume surge linked to MENA sanctions bypass","🏦 Swiss private banks report record MENA deposit surge","🛢️ Oil futures premium +$4.2/bbl war risk factor"];
  const text=items.join("   ·   ");
  return (
    <div style={{background:"#070910",borderBottom:`1px solid ${BORDER}`,padding:"7px 0",overflow:"hidden"}}>
      <style>{`@keyframes tk{from{transform:translateX(0)}to{transform:translateX(-50%)}}`}</style>
      <div style={{display:"flex",alignItems:"center"}}>
        <div style={{background:RED,color:"#fff",fontSize:9,fontWeight:900,padding:"3px 10px",letterSpacing:2,whiteSpace:"nowrap",marginLeft:12,flexShrink:0}}>● LIVE</div>
        <div style={{overflow:"hidden",flex:1,WebkitMaskImage:"linear-gradient(to right,transparent,black 5%,black 95%,transparent)"}}>
          <div style={{display:"inline-block",whiteSpace:"nowrap",color:GOLD,fontSize:10,fontFamily:"monospace",animation:"tk 65s linear infinite",paddingLeft:16}}>
            {text} · {text}
          </div>
        </div>
      </div>
    </div>
  );
}

function KPI({label,value,sub,color,pulse}) {
  return (
    <div style={{background:CARD,border:`1px solid ${BORDER}`,borderTop:`2px solid ${color}`,padding:"14px 16px"}}>
      <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,textTransform:"uppercase",marginBottom:6,fontFamily:"monospace"}}>{label}</div>
      <div style={{color,fontSize:20,fontWeight:900,fontFamily:"monospace",display:"flex",alignItems:"center",gap:6}}>
        {pulse&&<span style={{width:6,height:6,borderRadius:"50%",background:RED,display:"inline-block",animation:"blink 1.2s step-end infinite"}}/>}
        {value}
      </div>
      <div style={{color:"#3A4558",fontSize:9,marginTop:3}}>{sub}</div>
    </div>
  );
}

function RiskBadge({level}) {
  const map={LOW:GREEN,"LOW-MED":"#8BC34A",MED:"#FFA726","MED-HIGH":"#EF6C00",HIGH:RED};
  const c=map[level]||GOLD;
  return <span style={{background:c+"20",color:c,border:`1px solid ${c}40`,fontSize:8,padding:"2px 6px",letterSpacing:1.5,fontWeight:700}}>{level}</span>;
}

export default function App() {
  const [tab,setTab]=useState("FLOWS");
  const [sel,setSel]=useState(null);

  return (
    <div style={{background:DARK,color:"#B8C4D4",minHeight:"100vh",fontFamily:"monospace"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700;900&display=swap');
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
        *{box-sizing:border-box;margin:0;padding:0}
        .row:hover{background:#12171E!important;cursor:pointer}
        ::-webkit-scrollbar{width:3px;height:3px}
        ::-webkit-scrollbar-thumb{background:#252D3A}
      `}</style>

      {/* HEADER */}
      <div style={{background:"linear-gradient(90deg,#060809,#0C0F16)",borderBottom:`1px solid ${BORDER}`,padding:"13px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
        <div style={{display:"flex",alignItems:"center",gap:13}}>
          <div style={{width:40,height:40,background:`linear-gradient(135deg,${GOLD},${GOLD_DIM})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,color:DARK,fontWeight:900,fontFamily:"Cinzel,serif",flexShrink:0}}>𝔻</div>
          <div>
            <div style={{fontFamily:"Cinzel,serif",fontSize:14,color:GOLD,letterSpacing:3,fontWeight:900}}>DUBAI CAPITAL EXODUS TRACKER</div>
            <div style={{fontSize:8,color:"#3A4558",letterSpacing:2,marginTop:2}}>GEOPOLITICAL CAPITAL FLOW INTELLIGENCE · WAR-STATE EDITION</div>
          </div>
        </div>
        <div style={{textAlign:"right"}}>
          <div style={{fontSize:9,color:RED,fontWeight:700,letterSpacing:1}}>⚠ WAR STATE: ELEVATED</div>
          <div style={{fontSize:8,color:"#3A4558",marginTop:2}}>Mar 11, 2026 · 14:32 GST</div>
        </div>
      </div>

      <Ticker/>

      {/* KPIs */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:1,margin:"10px 10px 0",background:BORDER}}>
        <KPI label="Total MTD Outflow" value="$21.4B" sub="↑ 31.2% vs prior month" color={RED} pulse/>
        <KPI label="YTD Capital Exit" value="$89.7B" sub="Highest since 2022 crisis" color={GOLD}/>
        <KPI label="Top Destination" value="US T-Bills" sub="$6.1B · 28.5% of flows" color={BLUE}/>
        <KPI label="War Risk Index" value="74/100" sub="Iran + Red Sea drivers" color="#FF6B35"/>
      </div>

      {/* TABS */}
      <div style={{display:"flex",margin:"10px 10px 0",borderBottom:`1px solid ${BORDER}`,overflowX:"auto"}}>
        {["FLOWS","DESTINATIONS","WAR RISK","TRIGGERS"].map(t=>(
          <button key={t} onClick={()=>{setTab(t);setSel(null);}} style={{background:"none",border:"none",borderBottom:tab===t?`2px solid ${GOLD}`:"2px solid transparent",color:tab===t?GOLD:"#3A4558",padding:"8px 16px",fontSize:9,letterSpacing:2,fontWeight:700,fontFamily:"monospace",cursor:"pointer",whiteSpace:"nowrap",transition:"color 0.2s"}}>{t}</button>
        ))}
      </div>

      <div style={{padding:"10px 10px 24px"}}>

        {/* FLOWS */}
        {tab==="FLOWS"&&(
          <div style={{display:"grid",gap:8}}>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px"}}>
              <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:12}}>MONTHLY CAPITAL OUTFLOW COMPOSITION ($B)</div>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={monthlyFlow}>
                  <defs>
                    {[[GOLD,"g"],[BLUE,"b"],["#F7931A","c"],[GREEN,"r"]].map(([c,id])=>(
                      <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={c} stopOpacity={0.35}/><stop offset="95%" stopColor={c} stopOpacity={0}/>
                      </linearGradient>
                    ))}
                  </defs>
                  <XAxis dataKey="month" tick={{fill:"#3A4558",fontSize:9}} axisLine={false} tickLine={false}/>
                  <YAxis tick={{fill:"#3A4558",fontSize:9}} axisLine={false} tickLine={false}/>
                  <Tooltip contentStyle={{background:"#0D1018",border:`1px solid ${BORDER}`,color:GOLD,fontSize:9}}/>
                  <Area type="monotone" dataKey="gold" stackId="1" stroke={GOLD} fill="url(#g)" name="Gold"/>
                  <Area type="monotone" dataKey="bonds" stackId="1" stroke={BLUE} fill="url(#b)" name="Bonds"/>
                  <Area type="monotone" dataKey="re" stackId="1" stroke={GREEN} fill="url(#r)" name="Real Estate"/>
                  <Area type="monotone" dataKey="crypto" stackId="1" stroke="#F7931A" fill="url(#c)" name="Crypto"/>
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px"}}>
                <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:10}}>ASSET CLASS SPLIT (%)</div>
                <ResponsiveContainer width="100%" height={170}>
                  <PieChart>
                    <Pie data={sectorPie} cx="50%" cy="50%" innerRadius={48} outerRadius={70} dataKey="value" paddingAngle={3}>
                      {sectorPie.map((_,i)=><Cell key={i} fill={PIE_COLORS[i]}/>)}
                    </Pie>
                    <Tooltip contentStyle={{background:"#0D1018",border:`1px solid ${BORDER}`,color:GOLD,fontSize:9}}/>
                  </PieChart>
                </ResponsiveContainer>
                <div style={{display:"flex",flexWrap:"wrap",gap:"3px 12px",marginTop:4}}>
                  {sectorPie.map((s,i)=>(
                    <div key={i} style={{display:"flex",alignItems:"center",gap:4,fontSize:8,color:"#5A6478"}}>
                      <div style={{width:6,height:6,background:PIE_COLORS[i]}}/>
                      {s.name}
                    </div>
                  ))}
                </div>
              </div>
              <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px"}}>
                <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:10}}>FLOW BY DESTINATION ($B MTD)</div>
                <ResponsiveContainer width="100%" height={170}>
                  <BarChart data={destinations.map(d=>({name:d.code,flow:d.flow}))} barSize={16}>
                    <XAxis dataKey="name" tick={{fill:"#3A4558",fontSize:9}} axisLine={false} tickLine={false}/>
                    <YAxis tick={{fill:"#3A4558",fontSize:9}} axisLine={false} tickLine={false}/>
                    <Tooltip contentStyle={{background:"#0D1018",border:`1px solid ${BORDER}`,color:GOLD,fontSize:9}}/>
                    <Bar dataKey="flow" name="$B" radius={[2,2,0,0]}>
                      {destinations.map((d,i)=><Cell key={i} fill={d.color}/>)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* DESTINATIONS */}
        {tab==="DESTINATIONS"&&(
          <div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,overflowX:"auto"}}>
              <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr 2.5fr 2fr",padding:"9px 16px",borderBottom:`1px solid ${BORDER}`,color:"#3A4558",fontSize:7,letterSpacing:2,minWidth:640}}>
                <span>DESTINATION</span><span>FLOW</span><span>MoM</span><span>RISK</span><span>DRIVER</span><span>SECTORS</span>
              </div>
              {destinations.map((d,i)=>(
                <div key={i} className="row" onClick={()=>setSel(sel===i?null:i)} style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr 2.5fr 2fr",padding:"12px 16px",borderBottom:`1px solid ${BORDER}`,background:sel===i?"#12171E":"transparent",minWidth:640,alignItems:"center",transition:"background 0.15s"}}>
                  <div style={{display:"flex",alignItems:"center",gap:9}}>
                    <span style={{fontSize:18}}>{d.flag}</span>
                    <div>
                      <div style={{color:"#C8D0DC",fontWeight:700,fontSize:11}}>{d.name}</div>
                      <div style={{color:"#3A4558",fontSize:7,letterSpacing:1.5}}>{d.code}</div>
                    </div>
                  </div>
                  <div style={{color:GOLD,fontWeight:900,fontSize:12}}>${d.flow}B</div>
                  <div style={{color:d.change>0?GREEN:RED,fontWeight:700,fontSize:10}}>{d.change>0?"▲":"▼"}{Math.abs(d.change)}%</div>
                  <div><RiskBadge level={d.risk}/></div>
                  <div style={{color:"#5A6878",fontSize:9,lineHeight:1.4}}>{d.reason}</div>
                  <div style={{display:"flex",flexWrap:"wrap",gap:2}}>
                    {d.sectors.map((s,j)=>(
                      <span key={j} style={{background:d.color+"18",color:d.color,fontSize:7,padding:"2px 5px"}}>{s}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            {sel!==null&&(
              <div style={{background:"#0C1016",border:`1px solid ${destinations[sel].color}50`,borderTop:`2px solid ${destinations[sel].color}`,padding:16,marginTop:2}}>
                <div style={{display:"flex",gap:20,flexWrap:"wrap",alignItems:"flex-start"}}>
                  <div style={{flex:1,minWidth:180}}>
                    <div style={{fontFamily:"Cinzel,serif",color:destinations[sel].color,fontSize:13,marginBottom:9}}>{destinations[sel].flag} {destinations[sel].name}</div>
                    <div style={{fontSize:10,color:"#6A7A8E",lineHeight:2}}>
                      <span style={{color:GOLD}}>Driver: </span>{destinations[sel].reason}<br/>
                      <span style={{color:GOLD}}>Sectors: </span>{destinations[sel].sectors.join(", ")}<br/>
                      <span style={{color:GOLD}}>Risk: </span><RiskBadge level={destinations[sel].risk}/><br/>
                      <span style={{color:GOLD}}>MoM: </span><span style={{color:destinations[sel].change>0?GREEN:RED}}>{destinations[sel].change>0?"+":""}{destinations[sel].change}%</span>
                    </div>
                  </div>
                  <div style={{background:DARK,border:`1px solid ${BORDER}`,padding:"12px 16px",minWidth:160}}>
                    <div style={{color:"#3A4558",fontSize:7,letterSpacing:2,marginBottom:5}}>MTD FLOW</div>
                    <div style={{color:destinations[sel].color,fontSize:30,fontWeight:900}}>${destinations[sel].flow}B</div>
                    <div style={{color:"#3A4558",fontSize:8,marginTop:3}}>of $21.4B total</div>
                    <div style={{marginTop:8,height:3,background:"#1A2030",borderRadius:2}}>
                      <div style={{height:3,borderRadius:2,width:`${(destinations[sel].flow/21.4*100).toFixed(0)}%`,background:destinations[sel].color}}/>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* WAR RISK */}
        {tab==="WAR RISK"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px"}}>
              <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:8}}>THREAT VECTOR RADAR</div>
              <ResponsiveContainer width="100%" height={250}>
                <RadarChart data={warRisk} cx="50%" cy="50%" outerRadius="68%">
                  <PolarGrid stroke="#1A2030"/>
                  <PolarAngleAxis dataKey="subject" tick={{fill:"#5A6878",fontSize:8}}/>
                  <Radar dataKey="A" stroke={RED} fill={RED} fillOpacity={0.18}/>
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px"}}>
              <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:12}}>RISK LEVELS</div>
              {warRisk.map((w,i)=>(
                <div key={i} style={{marginBottom:12}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                    <span style={{fontSize:9,color:"#B8C4D4"}}>{w.subject}</span>
                    <span style={{fontSize:9,fontWeight:700,color:w.A>70?RED:w.A>55?"#FFA726":GREEN}}>{w.A}</span>
                  </div>
                  <div style={{height:3,background:"#1A2030",borderRadius:2}}>
                    <div style={{height:3,borderRadius:2,width:`${w.A}%`,background:w.A>70?`linear-gradient(90deg,${RED},#FF8050)`:w.A>55?"linear-gradient(90deg,#E07010,#FFC040)":`linear-gradient(90deg,${GREEN},#40E0A0)`}}/>
                  </div>
                </div>
              ))}
              <div style={{marginTop:14,padding:12,background:RED+"0D",border:`1px solid ${RED}30`}}>
                <div style={{color:RED,fontSize:8,fontWeight:700,letterSpacing:2,marginBottom:5}}>⚠ CRITICAL NEXUS</div>
                <div style={{fontSize:9,color:"#6A7A8E",lineHeight:1.8}}>Iran + Hormuz = dual energy shock vector. At 80+, expect <span style={{color:GOLD}}>gold/crypto flight</span> + <span style={{color:GOLD}}>T-Bill surge</span> within 48–72 hrs.</div>
              </div>
            </div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px",gridColumn:"1/-1"}}>
              <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:12}}>SCENARIO FORECAST</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                {[
                  {s:"SCENARIO A: Hormuz Closure",p:"18%",c:RED,f:["+$15–22B emergency","Gold +60–80%","Crypto +120%","USD T-Bills +40%"],t:"72hr spike"},
                  {s:"SCENARIO B: Iran-Israel Exchange",p:"34%",c:"#FF6B35",f:["+$8–12B acceleration","Oil +35%","SG/CH surge","AED volatility"],t:"1–2 week rebalance"},
                  {s:"SCENARIO C: Ceasefire",p:"48%",c:GREEN,f:["Partial return flows","RE stabilizes","Equities recover","Crypto profit-take"],t:"4–6 week normalization"},
                ].map((x,i)=>(
                  <div key={i} style={{border:`1px solid ${x.c}40`,borderTop:`2px solid ${x.c}`,padding:12}}>
                    <div style={{color:x.c,fontSize:9,fontWeight:700,marginBottom:3}}>{x.s}</div>
                    <div style={{color:"#3A4558",fontSize:8,marginBottom:8}}>Probability: <strong style={{color:x.c}}>{x.p}</strong></div>
                    {x.f.map((f,j)=><div key={j} style={{color:"#6A7A8E",fontSize:8,padding:"2px 0",borderBottom:`1px solid ${BORDER}`}}>→ {f}</div>)}
                    <div style={{marginTop:6,color:x.c,fontSize:7,letterSpacing:1}}>⏱ {x.t}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TRIGGERS */}
        {tab==="TRIGGERS"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,gridColumn:"1/-1",overflowX:"auto"}}>
              <div style={{padding:"10px 16px",borderBottom:`1px solid ${BORDER}`,color:"#3A4558",fontSize:8,letterSpacing:2}}>GEOPOLITICAL TRIGGER LOG</div>
              {triggers.map((t,i)=>(
                <div key={i} style={{display:"grid",gridTemplateColumns:"70px 1fr 170px 80px",padding:"12px 16px",borderBottom:`1px solid ${BORDER}`,alignItems:"center",gap:10,minWidth:520}}>
                  <div style={{color:GOLD,fontSize:9,fontWeight:700}}>{t.date}</div>
                  <div style={{color:"#C8D0DC",fontSize:10}}>{t.event}</div>
                  <div style={{color:GREEN,fontSize:9}}>{t.impact}</div>
                  <span style={{background:t.severity==="CRITICAL"?RED+"20":t.severity==="HIGH"?"#FF6B3520":GOLD+"20",color:t.severity==="CRITICAL"?RED:t.severity==="HIGH"?"#FF6B35":GOLD,border:`1px solid ${t.severity==="CRITICAL"?RED:t.severity==="HIGH"?"#FF6B35":GOLD}40`,fontSize:7,padding:"2px 6px",letterSpacing:1.5,fontWeight:700}}>{t.severity}</span>
                </div>
              ))}
            </div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px"}}>
              <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:12}}>SMART MONEY SIGNALS</div>
              {[
                {s:"Institutional gold buying",v:91,c:GOLD},
                {s:"USD T-Bill demand",v:85,c:BLUE},
                {s:"Crypto OTC desk volume",v:78,c:"#F7931A"},
                {s:"Singapore FO intake",v:72,c:GREEN},
                {s:"DFM net foreign selling",v:63,c:RED},
              ].map((x,i)=>(
                <div key={i} style={{marginBottom:13}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                    <span style={{color:"#B8C4D4",fontSize:9}}>{x.s}</span>
                    <span style={{color:x.c,fontWeight:700,fontSize:9}}>{x.v}/100</span>
                  </div>
                  <div style={{height:3,background:"#1A2030",borderRadius:2}}>
                    <div style={{height:3,borderRadius:2,width:`${x.v}%`,background:`linear-gradient(90deg,${x.c}70,${x.c})`}}/>
                  </div>
                </div>
              ))}
            </div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,padding:"16px 18px"}}>
              <div style={{color:"#3A4558",fontSize:8,letterSpacing:2,marginBottom:12}}>ANALYST THESIS</div>
              <div style={{fontSize:10,color:"#6A7A8E",lineHeight:2}}>
                <span style={{color:GOLD}}>Core: </span>Dubai sits at the nexus of Iran risk, Red Sea disruption, and GCC-West sanctions friction. Capital is not fleeing permanently — it is <em style={{color:"#B8C4D4"}}>hedging</em>.<br/><br/>
                <span style={{color:GOLD}}>Key: </span>The split between crypto (+63%) and T-Bills (+8%) reflects two investor profiles — sanctioned entities vs institutional GCC money.<br/><br/>
                <span style={{color:GOLD}}>Watch: </span>Singapore + Switzerland = the two valves regulating offshore vs return flows when de-escalation signals emerge.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
