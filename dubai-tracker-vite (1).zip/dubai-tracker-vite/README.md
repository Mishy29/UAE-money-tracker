# 🇦🇪 Dubai Capital Exodus Tracker (Vite)

## Run locally
```bash
npm install
npm run dev
```

## Deploy to Vercel
```bash
git init
git add .
git commit -m "Dubai tracker"
git remote add origin https://github.com/YOUR_USERNAME/dubai-capital-tracker.git
git push -u origin main
```
Then import on vercel.com — build command is `npm run build`, output is `dist`.
